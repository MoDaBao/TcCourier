//
//  ShopAddressViewController.h
//  TcCourier
//
//  Created by 莫大宝 on 16/10/31.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StoreInfoModel.h"

@interface ShopAddressViewController : UIViewController
@property (nonatomic, strong) StoreInfoModel *storeInfoModel;
//@property (nonatomic, copy) NSString *orderNumber;
//@property (nonatomic, assign) NSInteger index;

@end
