//
//  WaitReceiveOrderViewController.h
//  TcCourier
//
//  Created by 莫大宝 on 16/10/24.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaitReceiveOrderViewController : UIViewController

@property (nonatomic, assign) BOOL isJpush;
@property (nonatomic, copy) NSString *orderNumber;

@end
