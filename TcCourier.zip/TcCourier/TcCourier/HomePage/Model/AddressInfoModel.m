//
//  AddressInfoModel.m
//  TcCourier
//
//  Created by 莫大宝 on 2016/11/16.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "AddressInfoModel.h"

@implementation AddressInfoModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
