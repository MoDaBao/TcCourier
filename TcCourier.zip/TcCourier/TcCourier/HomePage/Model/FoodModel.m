//
//  FoodModel.m
//  TcCourier
//
//  Created by 莫大宝 on 2016/11/21.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "FoodModel.h"

@implementation FoodModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
