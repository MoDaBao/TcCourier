//
//  TodayCountModel.m
//  TcCourier
//
//  Created by 莫大宝 on 2016/12/22.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "TodayCountModel.h"

@implementation TodayCountModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
