//
//  RunFeeAndTiFeeView.h
//  TcCourier
//
//  Created by 莫大宝 on 2016/11/30.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RunFeeAndTiFeeView : UIView

- (void)loadRunFee:(NSString *)runFee tiFee:(NSString *)tiFee;

@end
