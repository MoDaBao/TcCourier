//
//  OrderDetailShopListView.h
//  TcCourier
//
//  Created by 莫大宝 on 2016/11/24.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FoodListView.h"
#import "StoreInfoModel.h"

@interface OrderDetailShopListView : UIView

- (void)loadOrderShopDetailListViewWithSotreInfoArray:(NSArray *)storeInfoArray;

@end
