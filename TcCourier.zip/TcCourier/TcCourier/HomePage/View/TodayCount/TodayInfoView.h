//
//  TodayInfoView.h
//  peisongduan
//
//  Created by 莫大宝 on 16/6/22.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TodayInfoItemVIew.h"

@interface TodayInfoView : UIView

- (instancetype)initWithFrame:(CGRect)frame dataArray:(NSMutableArray *)dataArray;



@end
