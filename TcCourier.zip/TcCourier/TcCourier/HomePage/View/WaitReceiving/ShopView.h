//
//  ShopView.h
//  TcCourier
//
//  Created by 莫大宝 on 2016/12/6.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopView : UIView

- (void)loadViewWithStoreInfoArray:(NSArray *)storeInfoArray;

@end
