//
//  TipMessageView.h
//  peisongduan
//
//  Created by 莫大宝 on 16/6/28.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TipMessageView : UIView

- (instancetype)initWithTip:(NSString *)tip;

@end
