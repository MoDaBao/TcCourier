//
//  MainTabBarButton.h
//  cmbfaeApp
//
//  Created by 余钦 on 16/6/24.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabBarButton : UIButton
@property(nonatomic, strong)UITabBarItem *tabBarItem;
@end
