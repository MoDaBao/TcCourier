//
//  SettingView.h
//  TcCourier
//
//  Created by 莫大宝 on 16/10/19.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingItemView.h"

@interface SettingView : UIView

@property (nonatomic, strong) SettingItemView *passwordItem;
@property (nonatomic, strong) SettingItemView *contactItem;

@end
