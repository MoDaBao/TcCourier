//
//  UIViewController+GetCurrentViewController.h
//  TcCourier
//
//  Created by 莫大宝 on 2016/12/22.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (GetCurrentViewController)

+ (UIViewController *)getCurrentViewController;

@end
